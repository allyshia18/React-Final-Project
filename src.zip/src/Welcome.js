
function Welcome() {


    return (
      <>
        
        <h1>Welcome to Fruit Pop!</h1>
        <p>Come Try The Best Frozen Dessert That's Healthy & Delicious</p>
        
      </>
    )
  }
  
  export default Welcome