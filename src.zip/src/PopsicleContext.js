import React from 'react'

const PopsicleContext = React.createContext()

export default PopsicleContext