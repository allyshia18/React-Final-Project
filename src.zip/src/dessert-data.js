
    const desserts= [
      {
        "id": 1,
        "name": "Strawberry Coconut Swirl Popscicle",
        "price": 4.5,
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Eget arcu dictum varius duis at consectetur lorem donec.",
        "dairyFree": true,
        "imgUrl": "https://images.unsplash.com/photo-1586769412527-ab0855979b2e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8aWNlY3JlYW18ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60"
      },
      {
        "id": 2,
        "name": "Green Apple & Ginger Lemonade Popsicle",
        "price": 5.5,
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "dairyFree": true,
        "imgUrl": "https://images.unsplash.com/photo-1626014268858-87f9d492a8c5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fHBvcHNpY2xlc3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
      },
      {
        "id": 3,
        "name": "Watermelon & Lime Relaxer Popsicle",
        "price": 4,
        "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Felis imperdiet proin fermentum leo vel orci porta non pulvinar.",
        "dairyFree": false,
        "imgUrl": "https://images.unsplash.com/photo-1625860648719-ab242656c04c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Njh8fHBvcHNpY2xlc3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
      }
    ]
//   export default desserts

module.exports = () => {
    return {desserts};
}